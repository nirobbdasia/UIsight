package com.apple.gcrm.insightui.pagefactory;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.apple.gcrm.insightui.util.TestBase;

public class Anamoly extends TestBase{
	Actions action=new Actions(driver);
	@FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div")
	WebElement anbutton;
	@FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div/div[1]/div/p")
	WebElement ndaystext;
	@FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div/div/div[1]/div[1]")
	WebElement showdrop;
	@FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div/div[1]/p[1]/i")
	WebElement warnbutton;
	@FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div/div[1]/p[2]/i")
	WebElement plussign;
	
public Anamoly() {
		PageFactory.initElements(driver, this);
	}
public boolean validateanamolybutton() {
	return anbutton.isDisplayed();
}
public boolean validatewarnbutton() {
	return warnbutton.isDisplayed();
}
public boolean validaetplussign() {
	return plussign.isDisplayed();
}
public String validatedaystext() {
	return ndaystext.getText();
}
public void insidethebutton() {
	
	action.moveToElement(ndaystext).build().perform();
	ndaystext.click();
}
public String showdroptext() {
	return showdrop.getText();
}
public int noofanamolies() throws InterruptedException {
	Thread.sleep(1000);
	
	String ancou = ndaystext.getText();
	String[] ocure = ancou.split(" ");
	int count = Integer.parseInt(ocure[0]);	
	return count;	
}

public boolean validatecollapse() {
	ndaystext.click();
	return plussign.isDisplayed();
	
}


}
