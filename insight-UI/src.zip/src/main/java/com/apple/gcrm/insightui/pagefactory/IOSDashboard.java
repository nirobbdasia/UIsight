package com.apple.gcrm.insightui.pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.apple.gcrm.insightui.util.TestBase;

public class IOSDashboard extends TestBase{
	
	@FindBy(xpath="//*[@id='root']/div/div[4]/div/label[1]/input")
	WebElement realTimeView;
	@FindBy(xpath="//*[@id='root']/div/div[4]/div/label[2]/input")
	WebElement snapShotView;
	@FindBy(xpath="//h2[contains(.,'iOS dashboard')]")
	WebElement appledash;
	@FindBy(xpath="//h3[contains(.,'Trending issues')]")
	WebElement componentissue;
	@FindBy(xpath="//h3[contains(.,'Trending issues')]/following-sibling::div/div[1]/img")
	WebElement combook;
	@FindBy(xpath="//h3[contains(.,'Trending issues')]/following-sibling::div/div[2]/img")
	WebElement comshare;
	@FindBy(xpath="//h3[contains(.,'Trending issues')]/following-sibling::div/div[3]/a")
	WebElement comex;
	@FindBy(xpath="//h3[contains(.,'Country')]")
	WebElement casesummary;
	@FindBy(xpath="//h3[contains(.,'Country')]/following-sibling::div/div[1]/img")
	WebElement casesummarybook;
	@FindBy(xpath="//h3[contains(.,'Country')]/following-sibling::div/div[2]/img")
	WebElement casesummaryshare;
	@FindBy(xpath="//h3[contains(.,'Country')]/following-sibling::div/div[3]/a")
	WebElement coex;
	
	@FindBy(xpath="//h3[contains(.,'Region')]")
	WebElement openhead;
	@FindBy(xpath="//h3[contains(.,'Region')]/following-sibling::div/div[1]/img")
	WebElement openbook;
	@FindBy(xpath="//h3[contains(.,'Region')]/following-sibling::div/div[2]/img")
	WebElement openshare;
	@FindBy(xpath="//h3[contains(.,'Region')]/following-sibling::div/div[3]/a")
	WebElement reex;
	
	@FindBy(xpath="//h3[contains(.,'Carrier')]")
	WebElement regionhead;
	@FindBy(xpath="//h3[contains(.,'Carrier')]/following-sibling::div/div[1]/img")
	WebElement regionbook;
	@FindBy(xpath="//h3[contains(.,'Carrier')]/following-sibling::div/div[2]/img")
	WebElement regionshare;
	@FindBy(xpath="//h3[contains(.,'Carrier')]/following-sibling::div/div[3]/a")
	WebElement regionex;
	
	@FindBy(xpath="//h3[contains(.,'Product')]")
	WebElement countryhead;
	@FindBy(xpath="//h3[contains(.,'Product')]/following-sibling::div/div[1]/img")
	WebElement countrybook;
	@FindBy(xpath="//h3[contains(.,'Product')]/following-sibling::div/div[2]/img")
	WebElement countryshare;
	@FindBy(xpath="//h3[contains(.,'Product')]/following-sibling::div/div[3]/a")
	WebElement countryex;
	
	@FindBy(xpath="//h3[contains(.,'Engg Project Code')]")
	WebElement producthead;
	@FindBy(xpath="//h3[contains(.,'Engg Project Code')]/following-sibling::div/div[1]/img")
	WebElement productbook;
	@FindBy(xpath="//h3[contains(.,'Engg Project Code')]/following-sibling::div/div[2]/img")
	WebElement productshare;
	@FindBy(xpath="//h3[contains(.,'Engg Project Code')]/following-sibling::div/div[3]/a")
	WebElement productex;
public IOSDashboard() {
		PageFactory.initElements(driver, this);
	}
public boolean validateRealview() {
	return realTimeView.isSelected();	
}
public boolean validateSnapview() {
	return snapShotView.isSelected();
}
public String validatedashboard() {
	return appledash.getText();
}

public String validatecomponentissuehead() {
	return componentissue.getText();
}
public boolean validatecombook() {
	return combook.isDisplayed();
}
public boolean validatecomshare() {
	return comshare.isDisplayed();
}
public boolean validatecomex() {
	return comex.isDisplayed();
}
public String validatecasetext() {
	return casesummary.getText();
}
public boolean validatecasesummarybook() {
	return casesummarybook.isDisplayed();
}
public boolean validatecasesummaryshare() {
	return casesummaryshare.isDisplayed();
}
public boolean validatecouex() {
	return coex.isDisplayed();
}
public String validateopentext() {
	return openhead.getText();
}
public boolean validateopenbook() {
	return openbook.isDisplayed();
}
public boolean validateopenshare() {
	return openshare.isDisplayed();
}
public boolean validatereex() {
	return reex.isDisplayed();
}

public String validateregionhead() {
	return regionhead.getText();
}
public boolean validateregionbook() {
	return regionbook.isDisplayed();
}
public boolean validateregionshare() {
	return regionshare.isDisplayed();
}
public boolean validateregionex() {
	return regionex.isDisplayed();
}

public String validatecountryhead() {
	return countryhead.getText();
}
public boolean validatecountrybook() {
	return countrybook.isDisplayed();
}
public boolean validatecountryshare() {
	return countryshare.isDisplayed();
}
public boolean validatecountryex() {
	return countryex.isDisplayed();
}

public String validateproducthead() {
	return producthead.getText();
}
public boolean validateproductbook() {
	return productbook.isDisplayed();
}
public boolean validateproductshare() {
	return productshare.isDisplayed();
}
public boolean validateproductex() {
	return productex.isDisplayed();
}

}