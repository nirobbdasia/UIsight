package com.apple.gcrm.insightui.util;

public class TestUtil {
	static int PAGE_LOAD_TIMEOUT=30;
	static int IMPLICIT_WAIT=40;
	

}
