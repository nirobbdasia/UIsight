package com.apple.gcrm.insightui.pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.apple.gcrm.insightui.util.TestBase;

public class HomePage extends TestBase{
	
	@FindBy(xpath=("//*[@class='top-menu-brand-text']"))
	WebElement home;
	
	//@FindBy(xpath="//h3[contains(.,'Cases')]")
	//@FindBy(xpath="//*[@id='root']/div/div[1]/div[1]/div[2]/h3/text()[2]")
	@FindBy(xpath= "//*[@id=\"root\"]/div/div[8]/div/div[1]/div[1]/div[2]/h3/text()[2]")
	WebElement Cases;
	//@FindBy(xpath=("//i[contains(@class,'fas fa-sticky-note')]"))
	//@FindBy(xpath=("//*[@id='root']/div/div[1]/div[1]/div[2]/h3/i"))//
	
	@FindBy(xpath="//*[@id=\"root\"]/div/div[8]/div/div[1]/div[1]/div[2]/h3/div")
	WebElement caseicon;
	
	//@FindBy(xpath="//h3[contains(.,'Cases')]/following-sibling::div/div/div/following-sibling::div/following-sibling::div[@class='difference']")
	@FindBy(xpath="//*[@id=\"root\"]/div/div[8]/div/div[1]/div[1]/div[2]/div/div[2]/div[3]/text()[2]")	

	WebElement caseyesterday;
	
	//@FindBy(xpath="//h3[contains(.,'Cases')]/following-sibling::div/div/div/following-sibling::div/i")
	@FindBy(xpath = "//*[@id=\"root\"]/div/div[8]/div/div[1]/div[1]/div[2]/div/div[2]/div[2]/div")
	WebElement arrowCases;
	
	//@FindBy(xpath="//*[@id='root']/div/div[1]/div[1]/div[2]/div/div[1]")	
	@FindBy (xpath = "//*[@id='root']/div/div[8]/div/div[1]/div[1]/div[2]/div/div[1]")
	WebElement casesLast;
	
	//@FindBy(xpath="//*[@id='root']/div/div[1]/div[1]/div[2]/div/div[2]/div[1]")
	@FindBy(xpath ="//*[@id='root']/div/div[8]/div/div[1]/div[1]/div[2]/div/div[2]/div[1]")
	WebElement casesUTC;
	
	//@FindBy(xpath="//h3[contains(.,'iOS Cases')]")
	@FindBy(xpath="//*[@id='root']/div/div[8]/div/div[1]/div[2]/div[2]/h3/text()[2]")
	WebElement iOS;
	
	//@FindBy(xpath=("//i[contains(@class,'fas fa-mobile-alt')]"))
	@FindBy(xpath = "//*[@id='root']/div/div[8]/div/div[1]/div[2]/div[2]/h3/div")
	WebElement ioscaseicon;
	
	//@FindBy(xpath="//h3[contains(.,'iOS Cases')]/following-sibling::div/div/div/following-sibling::div/following-sibling::div[@class='difference']")
	@FindBy(xpath = "//*[@id='root']/div/div[8]/div/div[1]/div[2]/div[2]/div/div[2]/div[3]/text()[2]")
	WebElement ioscaseyesterday;
	
	//@FindBy(xpath="//h3[contains(.,'iOS Cases')]/following-sibling::div/div/div/following-sibling::div/i")
	@FindBy(xpath = "//*[@id='root']/div/div[8]/div/div[1]/div[2]/div[2]/div/div[2]/div[2]/div")
	WebElement arrowiOSCases;
	
	//@FindBy(xpath="//*[@id='root']/div/div[1]/div[2]/div[2]/div/div[1]")
	@FindBy(xpath = "//*[@id='root']/div/div[8]/div/div[1]/div[2]/div[2]/div/div[1]")
	WebElement ioscasesLast;
	
	//@FindBy(xpath="//*[@id='root']/div/div[1]/div[2]/div[2]/div/div[2]/div[1]")
	@FindBy(xpath = "//*[@id=\"root\"]/div/div[8]/div/div[1]/div[2]/div[2]/div/div[2]/div[1]")
	WebElement ioscasesUTC;
	
	//@FindBy(xpath="//h3[contains(.,'Repairs')]")
	@FindBy(xpath="//*[@id='root']/div/div[1]/div[3]/div[2]/h3/text()[2]")
	WebElement repairs;
	@FindBy(xpath=("//i[contains(@class,'fas fa-wrench')]"))
	WebElement repairsicon;
	@FindBy(xpath="//h3[contains(.,'Repairs')]/following-sibling::div/div/div/following-sibling::div/following-sibling::div[@class='difference']")
	WebElement repairsyesterday;
	@FindBy(xpath="//h3[contains(.,'Repairs')]/following-sibling::div/div/div/following-sibling::div/i")
	WebElement arrowRep;
	@FindBy(xpath="//*[@id='root']/div/div[1]/div[3]/div[2]/div/div[1]")
	WebElement repLast;
	@FindBy(xpath="//*[@id='root']/div/div[1]/div[3]/div[2]/div/div[2]/div[1]")
	WebElement repUTC;
	
	//@FindBy(xpath="//h3[contains(.,'Reservations')]")
	@FindBy(xpath="//*[@id='root']/div/div[1]/div[4]/div[2]/h3/text()[2]")
	WebElement reservatios;
	@FindBy(xpath=("//i[contains(@class,'far fa-calendar-check')]"))
	WebElement reservatiosicon;
	@FindBy(xpath="//h3[contains(.,'Reservations')]/following-sibling::div/div/div/following-sibling::div/following-sibling::div[@class='difference']")
	WebElement reservatiosyesterday;
	@FindBy(xpath="//h3[contains(.,'Reservations')]/following-sibling::div/div/div/following-sibling::div/i")
	WebElement arrowRes;
	@FindBy(xpath="//*[@id='root']/div/div[1]/div[4]/div[2]/div/div[1]")
	WebElement resLast;
	@FindBy(xpath="//*[@id='root']/div/div[1]/div[4]/div[2]/div/div[2]/div[1]")
	WebElement resUTC;

	@FindBy(xpath="//*[@id='root']/div/div[4]/div/label[1]/input")
	WebElement realTimeView;
	@FindBy(xpath="//*[@id='root']/div/div[4]/div/label[2]/input")
	WebElement snapShotView;

public HomePage() {
	PageFactory.initElements(driver, this);
}

//Homepage
public String validateHomePageTitle() {
	return driver.getTitle();
}
public String homebanner() {
	return home.getText();
}

//Cases
public String validateCaseHeader() {
	return Cases.getText();
}
public boolean validatecaseicon() {
	return caseicon.isDisplayed();
}
public String validatecaseyesterday() {
	return caseyesterday.getText();
}
public boolean validatearrowcases() {
	return arrowCases.isDisplayed();
}
public String validatecaseslasttooltip() {
	return casesLast.getAttribute("data-tip");
}
public String validatecasesutctooltip() {
	return casesUTC.getAttribute("data-tip");
}

//iOSCases
public String validateiOSCaseHeader() {
	return iOS.getText();
}
public boolean validateioscaseicon() {
	return ioscaseicon.isDisplayed();
}
public String validateioscaseyesterday() {
	return ioscaseyesterday.getText();
}
public boolean validatearrowiOSCases() {
	return arrowiOSCases.isDisplayed();
}
public String validateioslasttooltip() {
	return ioscasesLast.getAttribute("data-tip");
}
public String validateioscasesutctooltip() {
	return ioscasesUTC.getAttribute("data-tip");
}
//Repairs
public String validaterepairHeader() {
	return repairs.getText();
}
public boolean validaterepairicon() {
	return repairsicon.isDisplayed();
}
public String validaterepairyesterday() {
	return repairsyesterday.getText();
}
public boolean validatearrowRep() {
	return arrowRep.isDisplayed();
}
public String validatereptooltip() {
	return repLast.getAttribute("data-tip");
}
public String validatereputctooltip() {
	return repUTC.getAttribute("data-tip");
}
//Reservations
public String validatereservatiosHeader() {
	return reservatios.getText();
}
public boolean validatereservatiosicon() {
	return reservatiosicon.isDisplayed();
}
public String validatereservatiosyesterday() {
	return reservatiosyesterday.getText();
}
public String validaterestooltip() {
	return resLast.getAttribute("data-tip");
}
public String validateiosresutctooltip() {
	return resUTC.getAttribute("data-tip");
}

public boolean validatearrowRes() {
	return arrowRes.isDisplayed();
}

//DefaultView
public boolean validateRealview() {
	return realTimeView.isSelected();	
}
public boolean validateSnapview() {
	return snapShotView.isSelected();
}

}