package com.apple.gcrm.insightui.stepdefinitions;

import com.apple.gcrm.insightui.pagefactory.Anamoly;
import com.apple.gcrm.insightui.pagefactory.HomePage;
import com.apple.gcrm.insightui.pagefactory.IOSDashboard;
import com.apple.gcrm.insightui.util.TestBase;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;


public class IOSDashboardSteps extends TestBase{
	IOSDashboard iosd;
		

	@Given("^User is on AppleCare dashboard of GCRM Insight$")
	public void user_is_on_AppleCare_dashboard_of_GCRM_Insight() throws Exception {
		TestBase.initialization();	
		iosd =new IOSDashboard();
		String dash=iosd.validatedashboard();
		Assert.assertEquals("iOS dashboard",dash);
	}
	@Given("^User is on Realtimeview of iOS dashboard$")
	public void user_is_on_Realtimeview_of_iOS_dashboard() throws Exception {
		iosd =new IOSDashboard();
		boolean flag=iosd.validateRealview();
		Assert.assertTrue(flag);
	}

	@When("^Verify user able to view \"([^\"]*)\" headertext on graph$")
	public void verify_user_able_to_view_headertext_on_graph(String arg1) throws Exception {
		iosd =new IOSDashboard();
		String comheader=iosd.validatecomponentissuehead();
		Assert.assertEquals("Trending issues",comheader);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to add as bookmark on Trending Issues graph$")
	public void verify_user_able_to_view_icon_to_add_as_bookmark_on_Trending_Issues_graph(String arg1) throws Exception {
	    boolean flag=iosd.validatecombook();
	    Assert.assertTrue(flag);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to share on Trending Issues Chart$")
	public void verify_user_able_to_view_icon_to_share_on_Trending_Issues_Chart(String arg1) throws Exception {
	    boolean csh=iosd.validatecomshare();
	    Assert.assertTrue(csh);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to exapand the view of Trending Issues graph$")
	public void verify_user_able_to_view_icon_to_exapand_the_view_of_Trending_Issues_graph(String arg1) throws Exception {
	   boolean cex=iosd.validatecomex();
	   Assert.assertTrue(cex);
	}
	
	@When("^Verify user able to view Country headertext on graph$")
	public void verify_user_able_to_view_Country_headertext_on_graph() throws Exception {
		String casesum=iosd.validatecasetext();
		Assert.assertEquals("Country", casesum);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to add as bookmark on Country graph$")
	public void verify_user_able_to_view_icon_to_add_as_bookmark_on_Country_graph(String arg1) throws Exception {
		 boolean flag=iosd.validatecasesummarybook();
		    Assert.assertTrue(flag);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to share on Country Chart$")
	public void verify_user_able_to_view_icon_to_share_on_Country_Chart(String arg1) throws Exception {
	    boolean flag=iosd.validatecasesummaryshare();
	    Assert.assertTrue(flag);
	}
	@Then("^Verify user able to view \"([^\"]*)\" icon to exapand the view of Country graph$")
	public void verify_user_able_to_view_icon_to_exapand_the_view_of_Country_graph(String arg1) throws Exception {
		boolean cex=iosd.validatecouex();
		   Assert.assertTrue(cex);
	}
	
	@When("^Verify user able to view Region headertext on graph$")
	public void verify_user_able_to_view_Region_headertext_on_graph() throws Exception {
		String actual=iosd.validateregionhead();
		Assert.assertEquals("Carrier", actual);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to add as bookmark on Region graph$")
	public void verify_user_able_to_view_icon_to_add_as_bookmark_on_Region_graph(String arg1) throws Exception {
		 boolean flag=iosd.validateregionbook();
		    Assert.assertTrue(flag);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to share on Region Chart$")
	public void verify_user_able_to_view_icon_to_share_on_Region_Chart(String arg1) throws Exception {
		 boolean flag=iosd.validateregionshare();
		    Assert.assertTrue(flag);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to exapand the view of Region graph$")
	public void verify_user_able_to_view_icon_to_exapand_the_view_of_Region_graph(String arg1) throws Exception {
		 boolean flag=iosd.validateregionex();
		    Assert.assertTrue(flag);
	}
	
	@When("^Verify user able to view Carrier headertext on graph$")
	public void verify_user_able_to_view_Carrier_headertext_on_graph() throws Exception {
		String actual=iosd.validateopentext();
		Assert.assertEquals("Region", actual);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to add as bookmark on Carrier graph$")
	public void verify_user_able_to_view_icon_to_add_as_bookmark_on_Carrier_graph(String arg1) throws Exception {
		 boolean flag=iosd.validateopenbook();
		    Assert.assertTrue(flag);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to share on Carrier Chart$")
	public void verify_user_able_to_view_icon_to_share_on_Carrier_Chart(String arg1) throws Exception {
		boolean flag=iosd.validateopenshare();
	    Assert.assertTrue(flag);
	}
	@Then("^Verify user able to view \"([^\"]*)\" icon to exapand the view of Carrier graph$")
	public void verify_user_able_to_view_icon_to_exapand_the_view_of_Carrier_graph(String arg1) throws Exception {
		boolean cex=iosd.validatereex();
		   Assert.assertTrue(cex);
	}


	@When("^Verify user able to view Product headertext on graph$")
	public void verify_user_able_to_view_Product_headertext_on_graph() throws Exception {
		String actual=iosd.validatecountryhead();
		Assert.assertEquals("Product", actual);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to add as bookmark on Product graph$")
	public void verify_user_able_to_view_icon_to_add_as_bookmark_on_Product_graph(String arg1) throws Exception {
		 boolean flag=iosd.validatecountrybook();
		    Assert.assertTrue(flag);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to share on Product Chart$")
	public void verify_user_able_to_view_icon_to_share_on_Product_Chart(String arg1) throws Exception {
		 boolean flag=iosd.validatecountryshare();
		    Assert.assertTrue(flag);
	}


	@Then("^Verify user able to view \"([^\"]*)\" icon to exapand the view of Product graph$")
	public void verify_user_able_to_view_icon_to_exapand_the_view_of_Product_graph(String arg1) throws Exception {
		 boolean flag=iosd.validatecountryex();
		    Assert.assertTrue(flag);
	}

	@When("^Verify user able to view Engg Project Code headertext on graph$")
	public void verify_user_able_to_view_Engg_Project_Code_headertext_on_graph() throws Exception {
		String actual=iosd.validateproducthead();
		Assert.assertEquals("Engg Project Code", actual);
	}
	
	@Then("^Verify user able to view \"([^\"]*)\" icon to add as bookmark on Engg Project Code graph$")
	public void verify_user_able_to_view_icon_to_add_as_bookmark_on_Engg_Project_Code_graph(String arg1) throws Exception {
		boolean flag=iosd.validateproductbook();
	    Assert.assertTrue(flag);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to share on Engg Project Code Chart$")
	public void verify_user_able_to_view_icon_to_share_on_Engg_Project_Code_Chart(String arg1) throws Exception {
		boolean flag=iosd.validateproductshare();
	    Assert.assertTrue(flag);
	}

	@Then("^Verify user able to view \"([^\"]*)\" icon to exapand the view of Engg Project Code graph$")
	public void verify_user_able_to_view_icon_to_exapand_the_view_of_Engg_Project_Code_graph(String arg1) throws Exception {
		boolean flag=iosd.validateproductex();
	    Assert.assertTrue(flag);
	}

	@Given("^User closes the browser to end the execution of iOSDashboard feature$")
	public void user_closes_the_browser_to_end_the_execution_of_iOSDashboard_feature() throws Exception {
	    driver.quit();
	}
}
