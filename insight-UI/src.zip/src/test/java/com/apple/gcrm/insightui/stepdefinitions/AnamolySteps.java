package com.apple.gcrm.insightui.stepdefinitions;

import com.apple.gcrm.insightui.pagefactory.Anamoly;
import com.apple.gcrm.insightui.util.TestBase;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import net.thucydides.core.annotations.Step;

public class AnamolySteps extends TestBase{
Anamoly ana;
	

	@Given("^User is on Homepage of GCRM$")
	public void user_is_on_Homepage_of_GCRM() throws Exception {
		TestBase.initialization();	
	}


	@Then("^Verify the anamoly button is present$")
	public void verify_the_anamoly_button_is_present() throws Exception {
		ana =new Anamoly();
	   boolean flag=ana.validateanamolybutton();
	   Assert.assertTrue(flag);
	}
	@Then("^Verify the number of anamolies found in last number of days text is present$")
	public void validte_the_number_of_anamolies_found_in_last_number_of_days_text_is_present() throws Exception {
	   String daystext=ana.validatedaystext();
	   String actual="anomalies found in last 1 day";
	   boolean isFound=actual.contains(actual);
	   Assert.assertTrue(isFound);
	}
	
	

	@When("^Verify ! Sign is present inserted in triangle$")
	public void verify_Sign_is_present_inserted_in_triangle() throws Exception {
	  boolean flag=ana.validatewarnbutton();
	  Assert.assertTrue(flag);
	}

	@Then("^Verify  \\+ Sign is present$")
	public void verify_Sign_is_present() throws Exception {
	    boolean flag=ana.validaetplussign();
	    Assert.assertTrue(flag);
	}
	
	@Given("^User is on Anamolies button$")
	public void user_is_on_Anamolies_button() throws Exception {
		ana =new Anamoly();
		   boolean flag=ana.validateanamolybutton();
		   Assert.assertTrue(flag);
	}

	
	@When("^User clicks the anamolies button to get inside$")
	public void user_clicks_the_anamolies_button_to_get_inside() throws Exception {
		ana =new Anamoly();
	    ana.insidethebutton();
	}
	
	@Given("^Verify \"([^\"]*)\" text$")
	public void verify_text(String arg1) throws Exception {
		boolean fla=false;
		ana =new Anamoly();
	   int ancount=ana.noofanamolies();
	   if(ancount>=1) {
		   fla=true;
		   System.out.println("\n\n\n\n\t\t\t\t\t\t\t\tNo of Anamolies found for 1 day::"+ancount+"\n\n\n\n");
	   }
	   Assert.assertTrue(fla);
	}

	@When("^Verify - sign should be present$")
	public void verify_sign_should_be_present() throws Exception {
		boolean flag=ana.validaetplussign();
	    Assert.assertTrue(flag);
	}

	@Then("^Verify \\+ sign should not be present$")
	public void verify_sign_should_not_be_present() throws Exception {
		boolean flag=ana.validaetplussign();
	    Assert.assertTrue(flag);
	}
	@When("^Verify number of anomalies showing are grater than zero and less than three$")
	public void verify_number_of_anomalies_showing_are_grater_than_zero_and_less_than_three() throws Exception {
		boolean fla=false;
		ana =new Anamoly();
	   int ancount=ana.noofanamolies();
	   if(ancount>0 && ancount<=3) {
		   fla=true;
		   System.out.println("\n\n\n\n\t\t\t\t\t\t\t\tNo of Anamolies found for 1 day::"+ancount+"\n\n\n\n");
	   }
	   Assert.assertTrue(fla);
	}

	@When("^Verify number of anomalies found more than three in last (\\d+) day$")
	public void verify_number_of_anomalies_found_more_than_three_in_last_day(int arg1) throws Exception {
		boolean fla=false;
		ana =new Anamoly();
	   int ancount=ana.noofanamolies();
	   if(ancount>=3) {
		   fla=true;
		   System.out.println("\n\n\n\n\t\t\t\t\t\t\t\tNo of Anamolies found for 1 day::"+ancount+"\n\n\n\n");
	   }
	   Assert.assertTrue(fla);
	}
	@When("^Verify number of anomalie found in last (\\d+) day is zero$")
	public void verify_number_of_anomalie_found_in_last_day_is_zero(int arg1) throws Exception {
		boolean fla=false;
		ana =new Anamoly();
	   int ancount=ana.noofanamolies();
	   if(ancount==0) {
		   fla=true;
		   System.out.println("\n\n\n\n\t\t\t\t\t\t\t\tNo of Anamolies found for 1 day::"+ancount+"\n\n\n\n");
	   }
	   Assert.assertTrue(fla);
	}

	@Then("^Verify a dropdown should show with default text as \"([^\"]*)\"$")
	public void verify_a_dropdown_should_show_with_default_text_as(String arg1) throws Exception {
		  ana=new Anamoly();
			String droptext=ana.showdroptext();
		   Assert.assertEquals("Show anomalies found in last", droptext);
	}

	@Then("^! Sign inserted in triangle should be present$")
	public void sign_inserted_in_triangle_should_be_present() throws Exception {
		boolean flag=ana.validatewarnbutton();
		  Assert.assertTrue(flag);
	}
	    
	
	@Then("^Verfiy a dropdown should show with default text \"([^\"]*)\"$")
	public void verfiy_a_dropdown_should_show_with_default_text(String arg1) throws Exception {
	   ana=new Anamoly();
		String droptext=ana.showdroptext();
	   Assert.assertEquals("Show anomalies found in last", droptext);
	}
	@Given("^Verify Anomly recangle box is expanded$")
	public void verify_Anomly_recangle_box_is_expanded() throws Exception {
		ana =new Anamoly();
	   ana.insidethebutton();
	}

	@When("^Verify \\+ sign is present in a box$")
	public void verify_sign_is_present_in_a_box() throws Exception {
		 boolean flag=ana.validaetplussign();
		    Assert.assertTrue(flag);
	}

	@Then("^Verify N anamolies found in last (\\d+) Day\" text is present$")
	public void verify_N_anamolies_found_in_last_Day_text_is_present(int arg1) throws Exception {
		 String daystext=ana.validatedaystext();
		   String actual="anomalies found in last 1 day";
		   boolean isFound=actual.contains(actual);
		   Assert.assertTrue(isFound);
	    
	}

	@Then("^Verify ! Sign is present on expanded box$")
	public void verify_Sign_is_present_on_expanded_box() throws Exception {
		boolean flag=ana.validatewarnbutton();
		  Assert.assertTrue(flag);
	}

	@Then("^Verfiy - Sign is not present$")
	public void verfiy_Sign_is_not_present() throws Exception {
	   boolean flag=ana.validatecollapse();
	   Assert.assertTrue(flag);
	   
	}
	@Given("^User closes the browser to end the execution of Anamoly feature$")
	public void user_closes_the_browser_to_end_the_execution_of_Anamoly_feature() throws Exception {
		driver.quit();
	}
	
}
