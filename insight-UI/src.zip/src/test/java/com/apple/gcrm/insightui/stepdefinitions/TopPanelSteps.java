package com.apple.gcrm.insightui.stepdefinitions;

import com.apple.gcrm.insightui.util.TestBase;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import com.apple.gcrm.insightui.pagefactory.HomePage;
import junit.framework.Assert;
import net.thucydides.core.annotations.Screenshots;
import net.thucydides.core.annotations.Step;


public class TopPanelSteps extends TestBase{
	
	HomePage homepage;
	
	String browserName=prop.getProperty("browser");
	@Given("^User opens \"Safari\" browser$")
	public void user_launches_browser(){
 
		TestBase.initialization();
	}
	
	@When("User in on Homepage")
	public void user_in_on_Homepage() {
		homepage =new HomePage();
		String home=homepage.homebanner();
	    Assert.assertEquals("GCRM Insight", home);	    
	}

	
	@Then("^Verify titile of landing page should be \"GCRM Insight Dashboard\"$")
	public void user_validates_the_Homepagetitle() {
	   String title =homepage.validateHomePageTitle();
	   Assert.assertEquals("GCRM Insight Dashboard", title);
	  
	}
	@Given("User validates Icon of Cases component is displayed")
	public void validate_icon_of_Cases_component()  {	
		homepage =new HomePage();		
		boolean flag=homepage.validatecaseicon();		
	    Assert.assertTrue(flag);	  
	}

	
	@When("User validates Header text \"Cases\" is displayed")
	public void validate_header_text_of_Cases() {
		String caseHeader=homepage.validateCaseHeader();
		System.out.println(caseHeader);
	    Assert.assertEquals("Cases", caseHeader);
	   
	}

	@Then("User validates Cases % than yesterday text is displayed")
	public void validate_Cases_of_than_yesterday_text() {
		String caseyes=homepage.validatecaseyesterday();
	    boolean isFound=caseyes.contains("than yesterday");
	    Assert.assertTrue(isFound);
	    
	}
	
	@Then("User validates arrow tip of Cases is displayed")
	public void validate_arrow_of_Cases() {
	    boolean flag=homepage.validatearrowcases();
	    Assert.assertTrue(flag);
	}
	
	@Then("User validates the tooltip \"Last hours trend\" is displayed on mousehover of graph under Cases component")
	public void validate_the_tooltip_on_Cases_of_graphs_as_Last_hours_trend() {
	    String caselast=homepage.validatecaseslasttooltip();
	    Assert.assertEquals("Last 24 hours trend", caselast);
	}

	@Then("User validates the tooltip \"Based on UTC\" is displayed on mousehover on Count under Cases component")
	public void validte_the_tooltip_on_Cases_of_count_as_Based_on_UTC()  {		
		String caseutc=homepage.validatecasesutctooltip();		
	    Assert.assertEquals("Based on UTC", caseutc);
	  
	}

	@Given("User validates Icon of iOSCases component is displayed")
	public void validate_icon_of_iOSCases_component() {
		homepage =new HomePage();
		boolean flag=homepage.validateioscaseicon();
	    Assert.assertTrue(flag);
	    
	}

	@When("User validates Header text of \"iOS Cases\" is displayed")
	public void validate_header_text_of_iOS_Cases() {
		String ioscHeader=homepage.validateiOSCaseHeader();
	    Assert.assertEquals("iOS Cases", ioscHeader);
	   
	}

	@Then("User validates iOS Cases % than yesterday text is displayed")
	public void validate_iOS_Cases_of_than_yesterday_text() {
		String ioscaseyes=homepage.validateioscaseyesterday();
	    boolean isFound=ioscaseyes.contains("than yesterday");
	    Assert.assertTrue(isFound);	   
	}
	
	@Then("User validates arrow tip of iOSCases is displayed")
	public void validate_arrow_of_iOSCases() {
	    boolean flag=homepage.validatearrowiOSCases();
	    Assert.assertTrue(flag);
	}
	@Then("User validates the tooltip \"Last hours trend\" is displayed on mousehover of graph under iOS Cases component")
	public void validate_the_tooltip_on_iOSCases_of_graphs_as_Last_hours_trend() {
	    String ioslast=homepage.validateioslasttooltip();
	    Assert.assertEquals("Last 24 hours trend", ioslast);
	}

	@Then("User validates the tooltip \"Based on UTC\" is displayed on mousehover on Count under iOS Component")
	public void validte_the_tooltip_on_iOSCases_of_count_as_Based_on_UTC() {
		String ioscaseutc=homepage.validateioscasesutctooltip();//validateiosresutctooltip();
	    Assert.assertEquals("Based on UTC", ioscaseutc);
	}

	@Given("User validates Icon of Repairs component is displayed")
	public void validate_icon_of_Repairs_component() {
		homepage =new HomePage();
		boolean flag=homepage.validaterepairicon();
	    Assert.assertTrue(flag);
	   
	}

	@When("User validates Header text of \"Repairs\" is displayed")
	public void validate_header_text_of_Repairs() {
		String reHeader=homepage.validaterepairHeader();
	    Assert.assertEquals("Repairs", reHeader);
	    
	}

	@Then("User validates Repairs % than yesterday text is displayed")
	public void validate_Repairs_of_than_yesterday_text() {
		String ioscaseyes=homepage.validaterepairyesterday();
	    boolean isFound=ioscaseyes.contains("than yesterday");
	    Assert.assertTrue(isFound);
	    
	}
	
	@Then("User validate arrow tip of Repairs is displayed")
	public void validate_arrow_of_Repairs() {
	    boolean flag=homepage.validatearrowRep();
	    Assert.assertTrue(flag);
	}
	@Then("User validates the tooltip \"Last hours trend\" is displayed on mousehover of graph under Repairs component")
	public void validate_the_tooltip_on_Repairs_of_graphs_as_Last_hours_trend() {
	 String replast=homepage.validatereptooltip();
	 Assert.assertEquals("Last 24 hours trend", replast);
	}

	@Then("User validates the tooltip \"Based on UTC\" is displayed on mousehover on Count under Repairs Component")
	public void validte_the_tooltip_on_Repairs_of_count_as_Based_on_UTC() {
		String reputc=homepage.validatereputctooltip();
	    Assert.assertEquals("Based on UTC", reputc);
	}

	@Given("User validates Icon of Reservations component is displayed")
	public void validate_icon_of_Reservatios_component() {
		homepage =new HomePage();
		boolean flag=homepage.validatereservatiosicon();
	    Assert.assertTrue(flag);
	    
	}

	@When("User validates Header text of \"Reservations\" is displayed")
	public void validate_header_text_of_Reservatios() {
		String resHeader=homepage.validatereservatiosHeader();
	    Assert.assertEquals("Reservations", resHeader);
	    
	}

	@Then("User validates Reservations % than yesterday text is displayed")
	public void validate_Reservations_of_than_yesterday_text() {
		String resytext=homepage.validatereservatiosyesterday();
	    boolean isFound=resytext.contains("than yesterday");
	    Assert.assertTrue(isFound);
	    
	}
	@Then("User validates arrow tip of Reservations is displayed")
	public void validate_arrow_of_Reservations() {
	   boolean flag=homepage.validatearrowRes();
	   Assert.assertTrue(flag);
	}
	
	@Then("User validates the tooltip \"Last hours trend\" is displayed on mousehover of graph under Reservations component")
	public void validate_the_tooltip_on_Reservations_of_graphs_as_Last_hours_trend() {
	    String reslast=homepage.validaterestooltip();
	    Assert.assertEquals("Last 24 hours trend", reslast);
	}

	@Then("User validates the tooltip \"Based on UTC\" is displayed on mousehover on Count under Reservations Component")
	public void validte_the_tooltip_on_Reservations_of_count_as_Based_on_UTC() {
		String resutc=homepage.validateiosresutctooltip();
	    Assert.assertEquals("Based on UTC", resutc);
	}
	
	@Given("Realtime View should be selected")
	public void validate_Realtime_View_as_Default_View() {
		homepage =new HomePage();
		boolean flag=homepage.validateRealview();
		Assert.assertTrue(flag);
	    
	}

	@Then("Snapshot View should be grayed")
	public void validate_Snapshot_View_as_grayed() {
		boolean flag=homepage.validateSnapview();
		Assert.assertFalse(flag);
		
		
	    
	}
	@Given("^User closes the browser to end the execution of Top Panel feature$")
	public void user_closes_the_browser_to_end_the_execution_of_Top_Panel_feature() throws Exception {
		driver.quit();
	}



}
